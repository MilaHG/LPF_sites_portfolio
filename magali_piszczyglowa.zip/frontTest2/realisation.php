<?php
require_once 'autoload.php';



$controller = new Controller\RealisationController; 

$controller->handlerRequest();