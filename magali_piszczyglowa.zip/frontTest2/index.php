<?php
require_once 'autoload.php';



$controller = new Controller\UserController; // me renvoie sur ma page profil
$controller->handlerRequest(); 
 








