<?php
require_once 'autoload.php';



$controller = new Controller\ContactController;

$controller->handlerRequest();