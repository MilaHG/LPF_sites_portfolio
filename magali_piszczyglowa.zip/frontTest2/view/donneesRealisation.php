<?php 
// var_dump($donnees);
//echo '<pre>'; print_r($fields); echo '</pre>';
?>
<?php 
$bdd= new PDO('mysql:host=localhost; dbname=mon_site_cv', 'root', '');

if(!empty($_FILES['photo']['name'])){//si name est different de vide, j'ai bien telecharger une photo
   $nom_photo=uniqid(). '-' . $_FILES['photo']['name'];//je genere un id unique pour chaque photo avec uniqid(). Avec ce code je definis le nom de la photo
//    echo $nom_photo .'<br>';

   $photoBdd= "http://localhost/support_poissy/frontTest2/web/$nom_photo";//me permet d'enregistrer le chemin dans la bdd. Il s'agit de l'url de l'image qui sera conservée en bdd
//    echo $photoBdd .'<br>';

   $photoDossier=$_SERVER['DOCUMENT_ROOT'] . "/frontTest2/web/$nom_photo";
   echo $_SERVER['DOCUMENT_ROOT'];
   //echo $photoDossier .'<br>';ce code me permet de definir le chemin complet du dossier. il me renvoie le chemin physique jusqu'à la racine du dossier, c-a-d,normalement, htdocs car c'est dans ce dossier que sont placés les dossiers relevant du php ( pour permettre l'utilisation de xampp lorsque l'on utilise xampp), afin de copier l'image dans le dossier, où elle sera stockée

   copy($_FILES['photo']['tmp_name'], $photoDossier); //ici je copie ma photo dans mon dossier . Il me faut pour ça le nom temporaire de la photo, que je trouve avec $_FILES['image']['tmp_name'], puis le nom du dossier (le chemin) où l'apporter, chemin que j'ai definis dans ma variable $photoDossier ci-dessus


$resultat=$bdd->exec("INSERT INTO t_realisation (photo) VALUES ('$photoBdd') ");//j'insere mes photos (leur url uniquement) uploadées dans ma bdd grâce à ce code . Ce code doit bien être dans la condition, sinon dès que l'on rafraichit la page, l'action s'effectue quand même et une insertion vide est faite dans la bdd, même si on ne choisit pas de fichier
}
?>
<div>
<form method="post" action="" enctype="multipart/form-data" class="col-md-6 offset-md-3 text-center">
  <div class="form-group">
    <label for="photo">Ajouter un document</label>
    <input type="file" class="form-control-file" id="photo" name="photo"><!--bien penser a mettre l'attribut name, sinon ca ne fonctionne pas-->
  </div>
  <button type="submit" class="btn btn-primary">Valider</button>
</form>
 <?php foreach($donnees as $key => $value):?> 
 
 
<div class="col-md-6 text-center p-2" id="realisation">
        <img src="<?= $value['photo'] ?>" alt="realisation" class="col-md-6" id="mesReal">
</div>
</div>

<?php endforeach; ?>
<div class="clear"></div>