<?php foreach($donnees as $value): ?>

<table class="table"  style="color:white">
  
  <tbody>
    <tr>
      <th scope="row"><?= $value['id_t_skill']?></th>
      <td><?= $value['competence']?></td>
      <td><?= $value['niveau']?>%</td>    
    </tr> 
  </tbody>
</table>

<?php endforeach; ?>