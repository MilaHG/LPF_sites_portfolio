<div class="card" id="profile" style="width: 25rem;">
<?php foreach($donnees as $key => $value): ?>
  <img class="card-img-top" src="./web/dino.jpg" alt="Card image cap">
  <div class="card-body">
    <p class="card-text">
    Bienvenue sur mon site CV.<br> Je suis <?= $value['prenom'] . " " . $value['nom'] ?> . Née le <?= $value['date_naissance'] ?>, je suis actuellement âgée de  <?= $value['age']?> ans. Je vis à <?= $value['ville'] ?> , en <?=$value['pays']?>.</p>

  </div>
</div>
<?php endforeach; ?>