<?php require_once'include/header.php'; ?>

<?php 
$entete = "intertitre";
$entetes = "intertitres";

require_once'tableau.php';
 ?>
 
<?php require_once'include/footer.php'; ?>