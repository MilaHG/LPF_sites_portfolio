<?php require_once'include/header.php'; ?>

<?php 
$entete = "titre_cv";
$entetes = "titres_cv";
require_once'tableau.php';
 ?>
 
<?php require_once'include/footer.php'; ?>