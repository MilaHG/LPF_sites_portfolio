<!-- Inclusion header -->
<?php require_once'include/header.php'; ?>

<!-- Requete noms et definition de la page courante -->

<?php 
$entete = "experience";
$entetes = "experiences";
require_once'tableau.php';
 ?>

<!-- Inclusion footer -->
 
<?php require_once'include/footer.php'; ?>