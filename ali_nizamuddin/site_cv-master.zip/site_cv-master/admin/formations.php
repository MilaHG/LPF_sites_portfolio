<?php require_once'include/header.php'; ?>

<?php 
$entete = "formation";
$entetes = "formations";
require_once'tableau.php';
 ?>
 
<?php require_once'include/footer.php'; ?>