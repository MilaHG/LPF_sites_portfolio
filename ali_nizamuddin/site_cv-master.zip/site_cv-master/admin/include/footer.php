
		</div>
	</div>
<footer>
	<span class="time">
		COPYRIGHT Ali MD Nizamuddin - 2017     
	</span>
</footer>
<script src="/site_cv/admin/asset/js/jquery-3.2.1.js"></script>

<script src="/site_cv/admin/asset/js/bootstrap.js"></script>

<script type="text/javascript" src="/site_cv/admin/asset/js/script.js"></script>
</body>
</html>