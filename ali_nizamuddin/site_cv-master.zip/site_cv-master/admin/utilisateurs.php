<?php require_once'include/header.php'; ?>

<?php 
$entete = "utilisateur";
$entetes = "utilisateurs";
require_once'tableau.php';


 ?>
 
<?php require_once'include/footer.php'; ?>