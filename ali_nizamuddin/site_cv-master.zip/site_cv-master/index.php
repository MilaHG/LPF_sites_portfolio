<?php 
header('Location:front/index.php');
?>