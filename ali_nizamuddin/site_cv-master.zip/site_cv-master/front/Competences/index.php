<!DOCTYPE html>
<html>
<head>
	<title>Competences</title>
</head>
<body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script type="text/javascript">
$(function(){
	window.location = "../index.php?index=1";
});
</script>
</body>
</html>