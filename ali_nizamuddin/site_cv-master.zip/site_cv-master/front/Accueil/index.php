<!DOCTYPE html>
<html>
<head>
	<title>Accueil</title>
</head>
<body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script type="text/javascript">
$(function(){
	window.location = "../index.php";
});
</script>
</body>
</html>