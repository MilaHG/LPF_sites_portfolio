<?php require_once("../inc/haut.inc.php") ?>

<?php require_once("../inc/bas.inc.php") ?>